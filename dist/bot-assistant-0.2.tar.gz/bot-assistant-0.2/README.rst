# Python Bot Assistant
Bot Assistant for Python to avoid getting Blocked for Web Scraping

Basic Features:

-> Generate & Set User Agents basedd on requirements

-> Make boy humanly with randomized waiting time and human like behaviours

-> Control Browser using selenium (Open Browser, Close Browser, Open New Tab, Close Tab, Go to Link)

-> Calculate Time in seconds or MilliSeconds


Best suitable for Web Scraping or Automation projects

USAGE:

from botAssistantModule import *

bot = botAssistant() # Create an Instance


